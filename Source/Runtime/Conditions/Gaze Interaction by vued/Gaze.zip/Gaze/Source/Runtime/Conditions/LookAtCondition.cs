﻿using Newtonsoft.Json;
using System.Runtime.Serialization;
using UnityEngine.Scripting;
using VRBuilder.BasicInteraction.Properties;
using VRBuilder.Core;
using VRBuilder.Core.Attributes;
using VRBuilder.Core.Conditions;
using VRBuilder.Core.SceneObjects;
using VRBuilder.Core.Utils;
using VRBuilder.Core.Validation;

namespace VRBuilder.BasicInteraction.Conditions
{
    /// <summary>
    /// Condition which is completed when PokeableProperty is poked.
    /// </summary>
    [DataContract(IsReference = true)]
    [HelpLink("https://www.mindport.co/vr-builder/manual/default-conditions/poke-object")] // TODO: Create docu
    public class LookAtCondition : Condition<LookAtCondition.EntityData>
    {
        [DisplayName("Look At Object")]
        public class EntityData : IConditionData
        {
#if CREATOR_PRO     
            [CheckForCollider] 
#endif
            [DataMember]
            [DisplayName("Object")]
            public ScenePropertyReference<IGazeableProperty> GazeableProperty { get; set; }

            [DataMember]
            [DisplayName("Time to trigger")]
            public float TimeToTrigger = 1.0f;

            public bool IsCompleted { get; set; }

            [DataMember]
            [HideInProcessInspector]
            public string Name { get; set; }

            public Metadata Metadata { get; set; }
        }

        private class ActiveProcess : BaseActiveProcessOverCompletable<EntityData>
        {
            public ActiveProcess(EntityData data) : base(data)
            {
                Data.GazeableProperty.Value.TimeToTrigger = Data.TimeToTrigger;
            }

            protected override bool CheckIfCompleted()
            {
                return Data.GazeableProperty.Value.IsBeingLookedAt;
            }
        }

        private class EntityAutocompleter : Autocompleter<EntityData>
        {
            public EntityAutocompleter(EntityData data) : base(data)
            {
            }

            public override void Complete()
            {
                Data.GazeableProperty.Value.FastForwardLookAt();
            }
        }

        [JsonConstructor, Preserve]
        public LookAtCondition() : this("")
        {
        }

        // ReSharper disable once SuggestBaseTypeForParameter
        public LookAtCondition(IGazeableProperty target, string name = null) : this(ProcessReferenceUtils.GetNameFrom(target), name)
        {
        }

        public LookAtCondition(string target, string name = "Look At Object")
        {
            Data.GazeableProperty = new ScenePropertyReference<IGazeableProperty>(target);
            Data.Name = name;
        }

        public override IStageProcess GetActiveProcess()
        {
            return new ActiveProcess(Data);
        }

        protected override IAutocompleter GetAutocompleter()
        {
            return new EntityAutocompleter(Data);
        }
    }
}